1. RUN getModels.sh from command line.
2. For Python program - you can change the mode by changing the MODE to COCO / MPI 
3. For C++ - you can change the mode by changing the #define to COCO / MPI 


# AI Courses by OpenCV

Want to become an expert in AI? [AI Courses by OpenCV](https://opencv.org/courses/) is a great place to start. 

<a href="https://opencv.org/courses/">
<p align="center"> 
<img src="https://www.learnopencv.com/wp-content/uploads/2020/04/AI-Courses-By-OpenCV-Github.png">
</p>
</a>
